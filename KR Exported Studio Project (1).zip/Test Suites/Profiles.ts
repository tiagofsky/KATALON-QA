<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Profiles</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f3f4647e-abe3-45cd-98ef-10e87e02f96f</testSuiteGuid>
   <testCaseLink>
      <guid>3bfe6a38-ac45-437a-a5c4-bcb049132738</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profiles/Sign out</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7054c988-9a78-416e-ab01-dd00c926a5a2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profiles/Log in Email/Pass</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dbf9b84f-3753-467e-ac91-d810cc06c1ce</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profiles/Create/Delete Profile</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    