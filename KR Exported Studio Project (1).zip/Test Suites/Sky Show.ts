<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Sky Show</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>22f757dd-6f60-4b1d-ae3d-b8fa4a6acb21</testSuiteGuid>
   <testCaseLink>
      <guid>afc23085-90f3-4325-b90f-03414c4f4614</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Show/ Live TV</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e220176a-5240-43d5-ae2e-d8876927f25a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Show/Browse Channels Live Tv</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ae60a551-3711-43d1-bde4-b3769bc33b62</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Show/Research and Start Content</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>380b2f16-a167-45bb-8a99-721065adcef4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Show/Add/Remove to my List copy </testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    