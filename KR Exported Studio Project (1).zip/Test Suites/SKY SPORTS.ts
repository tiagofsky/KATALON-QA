<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SKY SPORTS</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>9e6240a9-0cf2-4718-becc-0cd69488d15f</testSuiteGuid>
   <testCaseLink>
      <guid>7dd1c782-27ad-4fe7-b5c8-4b5eb2ded4f4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SKY SPORTS/Live Tv</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6b437ac3-3c99-4b31-b543-469f5ef53550</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SKY SPORTS/Browse Channels Live Tv</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>32cc7046-9c6f-41c1-a49b-51b88a0b157c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/SKY SPORTS/Add Team to Favourites / Research </testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    