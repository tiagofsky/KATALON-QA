<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Sky Store</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>22b0f9ff-5226-46a3-a4db-6f4fbc6ce853</testSuiteGuid>
   <testCaseLink>
      <guid>44df43fe-00f7-467b-a43e-98d1383158af</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Store/Add/Remove to my List</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7ca3091b-37b6-4022-95e8-a9fa24d3eaf6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Sky Store/My library</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    